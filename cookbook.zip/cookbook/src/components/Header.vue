<template>
 <div>
    <h1>Cook Book</h1>
    <v-col align="center">
       
     <router-link to="/">Home</router-link>
    &nbsp;
    <router-link to="/about">About</router-link>
    &nbsp;
    <router-link to="/nopage">nopage</router-link>
    </v-col>
 </div>
</template>
<style>
 #app
{
    background-color:#D8BFD8
}


</style>





