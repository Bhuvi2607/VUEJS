<template>
  <v-container style="min-width:400px;border-radius:30px 0 30px 0;border:10px double #CDB7F6; background:linear-gradient(0deg,#E9D3FF,#FFEFFF); box-shadow:0 0 15px black">
    <v-row>
      <v-col cols="4">
        <img
          style="width:100px;height:auto;"
          :src="food_image_url"
          alt="no image"
        />
      </v-col>
      <v-col cols="8">
        <v-row>
          <h3>{{name}}</h3>
        </v-row>
        <v-row>
          <v-icon color="secondary">mdi-youtube</v-icon>
          <a :href="youtube_Link"
          target="_blank"
          >follow this</a>
        </v-row>
        <v-row>
          <v-btn align="center" color="secondary" @click="openInstructions">procedure</v-btn>
        </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
export default {
  name: "FoodItem",
  props:{
    name:String,
    food_image_url:String,
    youtube_Link: String,
    instructions_text: String
    
  },
  methods: {
    openInstructions() {
      alert(
        this.instructions_text
      );
    },
  },
};
</script>

<style scoped>
.v-col {
  padding: 8px;
}
</style>

