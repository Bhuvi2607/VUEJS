<template>
<div>
    <h1>About Screen</h1>
    <v-img
  lazy-src="https://i.ytimg.com/vi/BEyloCJlpm0/maxresdefault.jpg"
  max-height="1000"
  max-width="750"
  src="https://i.ytimg.com/vi/BEyloCJlpm0/maxresdefault.jpg"
></v-img>
</div>
</template>